﻿namespace Miniboard.Data
{
    public interface IContextFactory
    {
        MiniboardContext CreateContext();
    }
}
